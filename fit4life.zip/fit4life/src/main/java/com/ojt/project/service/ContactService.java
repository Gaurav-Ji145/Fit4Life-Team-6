package com.ojt.project.service;

import com.ojt.project.entity.ContactForm;

public interface ContactService {
    void saveContactForm(ContactForm contactForm);
}